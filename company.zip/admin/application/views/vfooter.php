<?php
defined ('BASEPATH') OR exit('No direct script access allowed');
?>
 
    </div><!-- /#wrapper -->
    <!-- JavaScript -->
    <script src="<?php echo base_url("assets/js/jquery-1.10.2.js"); ?>"></script>
    <script src="<?php echo base_url("assets/js/bootstrap.js"); ?>"></script>

  </body>
</html>