/*
SQLyog Ultimate v9.02 
MySQL - 5.1.54-community : Database - db_cp
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*Table structure for table `tb_about` */

DROP TABLE IF EXISTS `tb_about`;

CREATE TABLE `tb_about` (
  `id` bigint(255) NOT NULL AUTO_INCREMENT,
  `page` varchar(100) NOT NULL,
  `judul` varchar(50) DEFAULT NULL,
  `deskripsi` text,
  `gambar` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`page`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `tb_about` */

insert  into `tb_about`(`id`,`page`,`judul`,`deskripsi`,`gambar`) values (1,'about','Gineal','GINEAL adalaha Usaha Pelayanan Jasa pemrograman dan Pembuatan Skripsi Teknik Informatika. Berdiri sejak tahun 2015 dan hingga sekarang melayani pemesanan lebih dari 30 kota besar.\r\n\r\n<p>\r\nKhusus bunga backdrop kami hanya melayani untuk wilayah JABODETABEK dan sekitarnya.Untuk luar kota kami hanya melayani pembelian bunga kertas dengan beberapa paket tertentu yang kami bisa kirim melalui jasa kurin pengiriman seperti JNE, TIKI, POS, danJNT.\r\n</p>\r\n\r\n<p>\r\nUntuk Payment kami menerima pembayaran secara Transfer ataupun payment melalui toko online kami di Tokopedia & Bukalapak.(*Khusus Pembelian Bunga Bouquet dan Bunga Kertas)\r\n</p>\r\n\r\n<p>\r\nUntuk jasa penyewaan Backdrop bunga kertas payment  langsung bayar ditempat (*Term & Conditions)\r\n</p>','page-1507199693.png');

/*Table structure for table `tb_company` */

DROP TABLE IF EXISTS `tb_company`;

CREATE TABLE `tb_company` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `company` varchar(100) NOT NULL,
  `alamat` varchar(100) DEFAULT NULL,
  `phone` varchar(100) DEFAULT NULL,
  `instagram` varchar(100) DEFAULT NULL,
  `twitter` varchar(100) DEFAULT NULL,
  `facebook` varchar(100) DEFAULT NULL,
  `google_maps` text,
  `email` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`company`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `tb_company` */

insert  into `tb_company`(`id`,`company`,`alamat`,`phone`,`instagram`,`twitter`,`facebook`,`google_maps`,`email`) values (2,'Gineal','Perum Pabuaran Indah Jl. Semangka Raya Blok L1 no 20','081219769706','@yokohama_store','@yokohama_store','-','https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3964.6250375578716!2d106.84466421477026!3d-6.442170895339231!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69ea6a046a0931%3A0x9e15874d11e069b6!2sYogu+Head+Office!5e0!3m2!1sid!2sid!4v1505323197416','faisalalamsyah1@gmail.com');

/*Table structure for table `tb_customer` */

DROP TABLE IF EXISTS `tb_customer`;

CREATE TABLE `tb_customer` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `customer` varchar(100) NOT NULL,
  `deskripsi` varchar(100) DEFAULT NULL,
  `website` varchar(100) DEFAULT NULL,
  `gambar` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`customer`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

/*Data for the table `tb_customer` */

insert  into `tb_customer`(`id`,`customer`,`deskripsi`,`website`,`gambar`) values (7,'dasdsad',NULL,'sdasdsad','customer-1507187753.JPG'),(8,'dfdsfsdf',NULL,'dfsdfsdf','customer-1507187786.JPG'),(9,'dfsdfdsf',NULL,'fsdfdsfsd','customer-1507187807.JPG'),(2,'faisal','aadasdsad','www.tobaco.com','customer1505683934.png'),(5,'sdasdfdsf',NULL,'fsdfsdfsdfds','customer1505685795.jpg'),(1,'Yokohama Store','dsadsadasd','www.tobaco.com','customer1505505404.jpg');

/*Table structure for table `tb_portfolio` */

DROP TABLE IF EXISTS `tb_portfolio`;

CREATE TABLE `tb_portfolio` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `judul` varchar(150) DEFAULT NULL,
  `slug` varchar(150) DEFAULT NULL,
  `deskripsi` text,
  `harga` float DEFAULT NULL,
  `gambar1` varchar(111) DEFAULT NULL,
  `gambar2` varchar(111) DEFAULT NULL,
  `gambar3` varchar(111) DEFAULT NULL,
  `gambar4` varchar(111) DEFAULT NULL,
  `gambar5` varchar(111) DEFAULT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

/*Data for the table `tb_portfolio` */

insert  into `tb_portfolio`(`id`,`judul`,`slug`,`deskripsi`,`harga`,`gambar1`,`gambar2`,`gambar3`,`gambar4`,`gambar5`) values (4,'Website Company Profile Dengan Codeigniter Dan Bootsrap','website_company_profile_dengan_codeigniter_dan_bootsrap','<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>',NULL,'portfolio1-1507166707.JPG','portfolio2-1507040633.jpg','portfolio3-1507040633.jpg','portfolio4-1507040633.jpg','portfolio5-1507040633.jpg'),(5,'Website Company Profile','website_company_profile','Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',NULL,'portfolio1-1507168970.JPG','portfolio2-1507168970.JPG','portfolio3-1507168970.JPG','portfolio4-1507168970.JPG','portfolio5-1507168970.JPG');

/*Table structure for table `tb_service` */

DROP TABLE IF EXISTS `tb_service`;

CREATE TABLE `tb_service` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `service` varchar(100) NOT NULL,
  `judul` varchar(100) DEFAULT NULL,
  `deskripsi` text,
  `gambar` varchar(100) DEFAULT NULL,
  `aktif` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`service`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `tb_service` */

insert  into `tb_service`(`id`,`service`,`judul`,`deskripsi`,`gambar`,`aktif`) values (3,'Test1','Test1','<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.','service-1505784951.jpg',NULL),(2,'test2','test2','Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.','service-1505784919.jpg',NULL),(4,'test3','test3','sdsadsadsa','service-1506664102.jpg',NULL),(1,'test4','test4','<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.','service-1505783748.jpg','active');

/*Table structure for table `tb_slide` */

DROP TABLE IF EXISTS `tb_slide`;

CREATE TABLE `tb_slide` (
  `id` bigint(255) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) DEFAULT NULL,
  `gambar` varchar(200) DEFAULT NULL,
  `gambar_png` varchar(200) DEFAULT NULL,
  `aktif` varchar(10) NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `tb_slide` */

insert  into `tb_slide`(`id`,`nama`,`gambar`,`gambar_png`,`aktif`) values (1,'Test','slide1-1507302688.jpg','slide2-1507302688.png','active');

/*Table structure for table `tb_user` */

DROP TABLE IF EXISTS `tb_user`;

CREATE TABLE `tb_user` (
  `id_user` bigint(20) NOT NULL AUTO_INCREMENT,
  `user` varchar(15) NOT NULL,
  `password` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`user`),
  UNIQUE KEY `id` (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `tb_user` */

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
